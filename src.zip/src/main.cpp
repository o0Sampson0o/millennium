#include <iostream>
#include <SFML/Graphics.hpp>
#include <Engine.hpp>

int main()
{
    Engine engine;
    engine.run();
    return EXIT_SUCCESS;
}